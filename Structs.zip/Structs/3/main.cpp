#include <iostream>
using namespace std;

int calcularAnos(double populacaoA, double populacaoB) {
    int anos = 0;
    while (populacaoA < populacaoB) {
        populacaoA *= 1.03;
        populacaoB *= 1.015;
        anos++;
    }
    return anos;
}

int main() {
    double populacaoA = 90000000;
    double populacaoB = 200000000;

    int anos = calcularAnos(populacaoA, populacaoB);
    cout << "Serao necessarios " << anos << " anos para a populacao do pais A ultrapassar a do pais B." << endl;

    return 0;
}
