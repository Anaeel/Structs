#include <iostream>
using namespace std;

int maior(int a, int b, int c) {
    if (a >= b && a >= c) return a;
    else if (b >= a && b >= c) return b;
    else return c;
}

int main() {
    int a, b, c;
    cout << "Digite 3 valores: ";
    cin >> a >> b >> c;

    cout << "O maior valor e: " << maior(a, b, c) << endl;
    return 0;
}
