#include <iostream>
#include <string>
using namespace std;

struct Aluno {
    int matricula;
    char nome[100];
};

int main() {
    Aluno alunos[50];
    int n;

    cout << "Digite o numero de alunos (maximo 50): ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        cout << "Digite a matricula do aluno " << i+1 << ": ";
        cin >> alunos[i].matricula;
        cout << "Digite o nome do aluno " << i+1 << ": ";
        cin.ignore();
        cin.getline(alunos[i].nome, 100);
    }

    cout << "\nDados dos alunos:\n";
    for (int i = 0; i < n; i++) {
        cout << "Matricula: " << alunos[i].matricula << ", Nome: " << alunos[i].nome << endl;
    }

    return 0;
}
