#include <iostream>
using namespace std;

double pesoIdeal(double altura, char sexo) {
    if (sexo == 'M' || sexo == 'm')
        return 72.7 * altura - 58;
    else if (sexo == 'F' || sexo == 'f')
        return 62.1 * altura - 44.7;
    else
        return 0.0;
}

int main() {
    double altura;
    char sexo;

    cout << "Digite a altura: ";
    cin >> altura;
    cout << "Digite o sexo (M/F): ";
    cin >> sexo;

    cout << "O peso ideal e: " << pesoIdeal(altura, sexo) << " kg" << endl;
    return 0;
}
