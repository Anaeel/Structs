#include <iostream>
using namespace std;

double fahrenheitToCelsius(int f) {
    return (5.0/9.0) * (f - 32);
}

int main() {
    cout << "Fahrenheit para Celsius de 0 a 100:\n";
    for (int f = 0; f <= 100; f++) {
        cout << "F: " << f << " = C: " << fahrenheitToCelsius(f) << endl;
    }
    return 0;
}
