#include <iostream>
using namespace std;

int idadeEmDias(int anos, int meses, int dias) {
    return anos * 365 + meses * 30 + dias;
}

int main() {
    int anos, meses, dias;
    cout << "Digite a idade (anos, meses, dias): ";
    cin >> anos >> meses >> dias;

    cout << "Idade em dias: " << idadeEmDias(anos, meses, dias) << endl;
    return 0;
}
